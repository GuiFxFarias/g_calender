export interface Tag {
  id: number;
  nome: string;
}
