export interface Anexo {
  id: number;
  arquivo_url: string;
  tipo: string;
  criado_em: string;
}
