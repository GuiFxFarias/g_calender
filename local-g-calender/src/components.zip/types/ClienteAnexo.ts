export interface ClienteAnexo {
  id: number;
  arquivo_url: string;
  tipo: string;
  nome_original: string;
  cliente_id: number;
  tenant_id: string;
}
