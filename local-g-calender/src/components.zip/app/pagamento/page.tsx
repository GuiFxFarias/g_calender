import PagamentoPage from './pagamentoPage';

export default function Page() {
  return (
    <div>
      <PagamentoPage />
    </div>
  );
}
