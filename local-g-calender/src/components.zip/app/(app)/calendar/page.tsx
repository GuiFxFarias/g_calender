import AgendaSemana from './agendaSemana';

export default function CalendarPage() {
  return (
    <div className='h-full'>
      <AgendaSemana />
    </div>
  );
}
