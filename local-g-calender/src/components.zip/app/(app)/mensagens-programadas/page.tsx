import MensagensProgramadasPage from './mensagensProgramadas';

export default function MensagemProgramada() {
  return (
    <div className='h-[100vh] overflow-y-auto max-md:h-[75vh]'>
      <MensagensProgramadasPage />
    </div>
  );
}
