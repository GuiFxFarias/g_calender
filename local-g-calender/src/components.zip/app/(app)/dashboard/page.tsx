import Dashboard from './graficosDash';

export default function DashboardPage() {
  return (
    <div className='h-[100vh]'>
      <Dashboard />
    </div>
  );
}
